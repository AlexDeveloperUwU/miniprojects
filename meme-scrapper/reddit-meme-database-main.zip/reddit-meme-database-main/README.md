# Reddit Meme Database

¡Bienvenido al Reddit Meme Database! Este repositorio sirve como almacenamiento para los memes obtenidos a través de un Reddit scraper. Si deseas contribuir añadiendo más subreddits de memes, sigue las instrucciones a continuación.

Por cierto, se hizo una limpieza de memes el día 02/12/2023 para implementar el nuevo sistema de gestión de antiguedad, es por ello que por eso contamos con menos memes que de costumbre.

# Conteo de memes

Ahora mismo contamos con 2343 memes en nuestra base de datos. Actualizado el día 14/12/2023

# Uso de los Memes

¡Estamos encantados de compartir estos memes contigo para que los utilices en tus proyectos creativos! Para acceder a la última colección de memes optimizados, te recomendamos utilizar el archivo JSON disponible en el enlace [RAW](https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/memes.json). Utilizar este enlace asegurará que siempre tengas acceso a la versión más actualizada de la base de datos de memes.

## Actualizaciones Frecuentes

Los memes se actualizan automáticamente cada 2 horas. Si se añade un meme nuevo, este se reflejará tanto en el archivo JSON como en el repositorio, lo que garantiza que siempre tengas acceso a los memes más recientes para tus proyectos.

## Memes Optimizados

Para mejorar la velocidad de carga y reducir el espacio ocupado, todos los memes han sido optimizados. Su calidad se ha ajustado al 80% de la calidad original, lo que permite una experiencia fluida al cargar los memes en tus aplicaciones.

## Estructura del Repositorio

- `/Memes`: Contiene las subcarpetas de cada subreddit con los archivos de memes correspondientes.
- `scripts.md`: Proporciona información detallada sobre los scripts utilizados en este proyecto.
- `memes.json`: Archivo JSON generado que almacena información sobre los memes y sus subreddits.

## Contribución de Subreddits

Si deseas añadir más subreddits de memes a esta base de datos, simplemente sigue estos pasos:

1. Abre el archivo `scripts.md` para obtener información sobre cómo funciona este proyecto y cómo contribuir.

2. Ubica el array que contiene los nombres de los subreddits en el archivo `scrapper.js`.

3. Añade un nuevo nombre de subreddit siguiendo el formato existente en el array.

4. Guarda los cambios y genera un nuevo pull request

## Acerca del Autor

Este repositorio fue creado por [AlexDeveloperUwU](https://github.com/AlexDeveloperUwU), con el objetivo de proporcionar un espacio para almacenar memes recopilados de diversos subreddits. La decisión de alojarlo aquí en lugar de en su cuenta principal se debe a preocupaciones sobre posibles baneos debido a la gran cantidad de archivos que este proyecto contiene y genera.
