const fs = require('fs');

function updateReadmeWithMemeCount(count) {
  // Actualizamos el archivo readme.md con el nuevo conteo y la fecha
  const currentDate = new Date().toLocaleDateString('es-ES');
  const readmePath = 'README.md';
  
  fs.readFile(readmePath, 'utf8', (err, data) => {
    if (err) {
      console.error("Error reading readme.md:", err);
      return;
    }

    const updatedReadme = data.replace(
      /Ahora mismo contamos con \d+ memes en nuestra base de datos. Actualizado el día \d+\/\d+\/\d+/,
      `Ahora mismo contamos con ${count} memes en nuestra base de datos. Actualizado el día ${currentDate}`
    );

    fs.writeFile(readmePath, updatedReadme, 'utf8', (err) => {
      if (err) {
        console.error("Error writing to readme.md:", err);
        return;
      }
      console.log(`readme.md actualizado con el nuevo conteo: ${count}`);
    });
  });
}

// Lee y carga el archivo memes.json localmente
fs.readFile('memes.json', 'utf8', (err, data) => {
  if (err) {
    console.error("Error reading memes.json:", err);
    return;
  }

  const json = JSON.parse(data);

  // Filtramos los objetos en el JSON que tienen una propiedad 'url' definida y contamos cuántos cumplen con esto
  const urlCount = json.filter(obj => obj.url).length;

  // Actualiza el archivo readme.md con el nuevo conteo y la fecha
  updateReadmeWithMemeCount(urlCount);
});
