const fs = require('fs');
const path = require('path');

const memesFolderPath = './Memes'; // Ruta a la carpeta principal de memes
const outputFilePath = 'memes.json'; // Nombre del archivo de salida

// Función para obtener la información de cada meme
function processMeme(subreddit, fileName) {
    const url = `https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/Memes/${subreddit}/${fileName}`;
    return {
        fileName: fileName,
        folderName: subreddit,
        url: url
    };
}

// Función para recorrer los archivos y subcarpetas
function exploreDirectory(directoryPath) {
    const subreddits = fs.readdirSync(directoryPath, { withFileTypes: true });

    const memeData = [];

    subreddits.forEach(subredditDir => {
        if (subredditDir.isDirectory()) {
            const subreddit = subredditDir.name;
            const subredditPath = path.join(directoryPath, subreddit);

            const memeFiles = fs.readdirSync(subredditPath);
            memeFiles.forEach(fileName => {
                const memeInfo = processMeme(subreddit, fileName);
                memeData.push(memeInfo);
            });
        }
    });

    return memeData;
}

// Ejecutar el script
const memeData = exploreDirectory(memesFolderPath);
const jsonData = JSON.stringify(memeData, null, 2);

fs.writeFileSync(outputFilePath, jsonData);

console.log(`Se ha creado el archivo ${outputFilePath} con la información de los memes.`);
