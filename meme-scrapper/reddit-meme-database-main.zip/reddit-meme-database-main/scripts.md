# Scripts

Hay varios scripts últiles para el proyecto y que sirven para automatizarlo:

jsonmaker.js => Genera el json donde se almacenan todos los memes

optimize.js => Optimiza todas las imágenes (solo si no están ya optimizadas)

readmeupdater.js => Actualiza el número de memes que existen en la base de datos

scrapper.js => Obtiene los memes nuevos que no estén presentes en las carpetas

deleter.js => Elimina aquellos memes que son más viejos que 1 mes

# Ejemplos

En la carpeta "examples" podrás encontrar ejemplos de distintas cosas que puedes realizar con este repositorio.

Habrá ejemplos en python y node.js con distintos casos de uso.
