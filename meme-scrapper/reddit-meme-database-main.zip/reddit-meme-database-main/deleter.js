const fs = require('fs').promises;
const path = require('path');
const moment = require('moment');

const memesFolder = './Memes';
const jsonFilePath = './memes.json';

const currentDate = moment();

async function deleteOldMemes(folderPath, memesData) {
  try {
    const files = await fs.readdir(folderPath);

    for (const file of files) {
      const filePath = path.join(folderPath, file);
      const fileStats = await fs.stat(filePath);

      if (fileStats.isDirectory()) {
        await deleteOldMemes(filePath, memesData);
      } else {
        const fileDateMatch = file.match(/(\d{2}-\d{2}-\d{4})/);
        if (fileDateMatch) {
          const fileDate = moment(fileDateMatch[0], 'DD-MM-YYYY');
          const daysDiff = currentDate.diff(fileDate, 'days');

          if (daysDiff > 30) {
            await fs.unlink(filePath);
            console.log(`Deleted: ${filePath}`);

            const fileNameToDelete = file;
            const indexToDelete = memesData.findIndex((meme) => meme.fileName === fileNameToDelete);
            if (indexToDelete !== -1) {
              memesData.splice(indexToDelete, 1);
              console.log(`Deleted JSON entry for: ${fileNameToDelete}`);
            }
          }
        }
      }
    }

    await fs.writeFile(jsonFilePath, JSON.stringify(memesData, null, 2));
    console.log('Updated JSON file.');
  } catch (error) {
    console.error('Error:', error);
  }
}

async function main() {
  let memesData = [];

  try {
    const jsonData = await fs.readFile(jsonFilePath, 'utf8');
    memesData = JSON.parse(jsonData);
  } catch (error) {
    console.error('Error reading JSON file:', error);
  }

  await deleteOldMemes(memesFolder, memesData);
}

main();
