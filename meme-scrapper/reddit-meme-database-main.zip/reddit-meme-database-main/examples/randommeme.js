// Importamos la librería Axios para hacer solicitudes HTTP
const axios = require('axios');

// Definimos una función asíncrona llamada 'getRandomMemeUrl'
async function getRandomMemeUrl() {
    try {
        // Intentamos realizar una solicitud GET a la URL proporcionada que contiene un archivo JSON
        const response = await axios.get('https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/memes.json');
        
        // Obtenemos los datos JSON de la respuesta
        const json = response.data;
        
        // Generamos un índice aleatorio basado en la longitud del array JSON
        const randomIndex = Math.floor(Math.random() * json.length);
        
        // Obtenemos la URL de un meme aleatorio utilizando el índice generado
        const randomUrl = json[randomIndex].url;
        
        // Imprimimos la URL del meme aleatorio en la consola
        console.log(randomUrl);
    } catch(error) {
        // Si ocurre un error durante la solicitud, lo capturamos y lo imprimimos en la consola
        console.log(error);
    }
}

// Llamamos a la función para obtener y mostrar una URL de meme aleatoria
getRandomMemeUrl();
