// Importamos la librería Axios, que nos permite hacer solicitudes HTTP
const axios = require('axios');

// Definimos una función asíncrona llamada 'getCountOfUrlsFromJson'
async function getCountOfUrlsFromJson() {
  // Realizamos una solicitud GET a la URL proporcionada que contiene un archivo JSON
  const response = await axios.get('https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/memes.json');
  
  // Extraemos los datos JSON de la respuesta
  const json = response.data;
  
  // Filtramos los objetos en el JSON que tienen una propiedad 'url' definida y contamos cuántos cumplen con esto
  const urlCount = json.filter(obj => obj.url).length; // Filtrar los objetos con la propiedad .url y contarlos
  
  // Imprimimos en la consola la cantidad de URLs encontradas en el JSON
  console.log(`Cantidad de URLs en el JSON: ${urlCount}`);
}

// Llamamos a la función para que se ejecute y realice las operaciones
getCountOfUrlsFromJson();
