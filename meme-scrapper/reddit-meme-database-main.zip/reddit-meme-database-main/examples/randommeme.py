# Importamos la librería 'requests' para hacer solicitudes HTTP y la librería 'random' para generar números aleatorios
import requests
import random

# Definimos una función llamada 'get_random_meme_url'
def get_random_meme_url():
    try:
        # Intentamos realizar una solicitud GET a la URL proporcionada que contiene un archivo JSON
        response = requests.get('https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/memes.json')
        
        # Obtenemos los datos JSON de la respuesta
        json_data = response.json()
        
        # Generamos un índice aleatorio dentro del rango de los índices válidos del array JSON
        random_index = random.randint(0, len(json_data) - 1)
        
        # Obtenemos la URL de un meme aleatorio utilizando el índice generado
        random_url = json_data[random_index]['url']
        
        # Imprimimos la URL del meme aleatorio en la consola
        print(random_url)
    except Exception as error:
        # Si ocurre un error durante la solicitud o el proceso, lo capturamos y lo imprimimos en la consola
        print(error)

# Llamamos a la función para obtener y mostrar una URL de meme aleatoria
get_random_meme_url()
