# Importamos la librería 'requests', que nos permite hacer solicitudes HTTP
import requests

# Definimos una función llamada 'get_count_of_urls_from_json'
def get_count_of_urls_from_json():
    # Realizamos una solicitud GET a la URL proporcionada que contiene un archivo JSON
    response = requests.get('https://raw.githubusercontent.com/AlexDevFiles/reddit-meme-database/main/memes.json')
    
    # Obtenemos los datos JSON de la respuesta
    json_data = response.json()
    
    # Filtramos los objetos en el JSON que tienen la propiedad 'url' definida y contamos cuántos cumplen con esto
    url_count = len([obj for obj in json_data if obj.get('url')]) # Filtrar objetos con la propiedad 'url' y contarlos
    
    # Imprimimos en la consola la cantidad de URLs encontradas en el JSON
    print(f"Cantidad de URLs en el JSON: {url_count}")

# Llamamos a la función para que se ejecute y realice las operaciones
get_count_of_urls_from_json()
